#include <iomanip>
#include <iostream>
#include <fstream>
#include <sstream>
#include <bitset>
#include <string>

// variables
const unsigned uBits = 4;
std::string lines[10000];
std::string op[10000];
std::string addr[10000];
std::string addrBin[10000];

// function prototypes
void openFile(std::ifstream &inFile, char* filename);
std::string getLine(std::ifstream &inFile);
std::string hex2Bin(std::string str);

int main(int argc, char* argv[])
{
	std::cout << std::endl;
	std::cout << "________________________________________________________________" << std::endl;
	std::cout << std::endl;
	std::cout << "Trace file count: " << argc-1 << std::endl;
	for (int i = 1; i < argc; i++) {
		std::cout << "Filename(" << i << "): " << argv[i] << std::endl;
	}
	std::cout << std::endl;

	for (int i = 1; i < argc; i++) {
		std::ifstream inFile;
		openFile(inFile, argv[i]);
		std::cout << "________________________________________________________________" << std::endl;
		std::cout << "        Opcode   Address(hex)            Address(binary)" << std::endl;
		int n = 0;
		while (!inFile.eof()) {
			lines[n] = getLine(inFile);
			op[n] = lines[n].at(0);
			addr[n] = lines[n].substr(2, 8);
			addrBin[n] = hex2Bin(addr[n]);
			std::cout << "Line " << n+1 << ":   " << op[n] << "       " << addr[n] << "       " << addrBin[n] << std::endl;
			n++;
		}
		inFile.close();
	}
	return 0;
}

// Opens file, does sanity check. Continues if file is valid.
void openFile(std::ifstream &inFile, char* filename) 
{
	inFile.open(filename);

	if (!inFile.is_open())
	{
		std::cout << "Error opening trace file." << std::endl;
		exit(0);
	}
	else
	{
		std::cout << filename << " loaded." << std::endl;
	}
}

// Reads a single line from the currently open file, appends any
// necessary leading zeros, and returns the line.
std::string getLine(std::ifstream &inFile)
{
	std::string line;
	std::string fill = "0";
	getline(inFile, line);
	int fillNumber = line.length() - 10;
	if (fillNumber < 0) {
		//std::cout << "Address is less than 8 bits" << std::endl;
		for (int i = 0; i < abs(fillNumber); i++) {
			line.insert(2, fill);
		}
	}
	else 
	{
		//std::cout << "Address is 8 bits" << std::endl;
	}
	return line;
}

std::string hex2Bin(std::string str)
{
	//std::cout << str;
	std::string binDigitsArr[8];
	std::string binDigits;
	std::string s2;
	for (int i = 0; i < str.length(); i++) {
		s2 = "0x" + str.substr(i,1);
		//std::cout << s2;
		std::stringstream ss;
		ss << std::hex << s2;
		unsigned n;
		ss >> n;
		std::bitset<uBits> b(n);
		binDigitsArr[i] = b.to_string();
		//std::cout << binDigitsArr[i];
		binDigits.insert(i * 4, binDigitsArr[i]);
	}
	return binDigits;
}
